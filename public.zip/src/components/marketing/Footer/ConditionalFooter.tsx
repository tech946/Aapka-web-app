'use client';

import { usePathname } from 'next/navigation';
import Footer from './Footer';

export default function ConditionalFooter() {
  const pathname = usePathname();

  // Hide footer on dashboard routes and maintenance page
  const isDashboardRoute = pathname?.startsWith('/dashboard');
  const isMaintenancePage = pathname === '/';

  if (isDashboardRoute || isMaintenancePage) {
    return null;
  }

  return <Footer />;
}
