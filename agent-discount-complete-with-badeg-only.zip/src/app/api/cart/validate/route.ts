import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { createServerSupabaseClient } from '@/lib/supabase-server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface DateRange {
  id: string;
  fromDate: string;
  toDate: string;
  adultPrice: number;
  childPrice: number;
  infantPrice: number;
  soloTravellerPrice?: number | null;
  isSoldOut: boolean;
}

interface CartItemRequest {
  packageId: string;
  adults: number;
  children: number;
  infants: number;
  selectedDate: string | null;
  isSoloTraveller?: boolean;
  withVisa?: boolean;
  visaForAdults?: number;
  visaForChildren?: number;
  visaForInfants?: number;
}

// Helper function to check if discount is active
function isDiscountActive(pkg: any): boolean {
  if (!pkg.discount_start_date || !pkg.discount_end_date) return false;
  
  const hasDiscount = (pkg.adult_discount_amount && pkg.adult_discount_amount > 0) ||
    (pkg.child_discount_amount && pkg.child_discount_amount > 0) ||
    (pkg.infant_discount_amount && pkg.infant_discount_amount > 0);
  
  if (!hasDiscount) return false;
  
  const now = new Date();
  const startDate = new Date(pkg.discount_start_date);
  const endDate = new Date(pkg.discount_end_date);
  endDate.setHours(23, 59, 59, 999);
  
  return now >= startDate && now <= endDate;
}

// Helper function to find the date range that contains a given date
function findDateRangeForDate(dateRanges: DateRange[] | null | undefined, dateStr: string): DateRange | null {
  if (!dateRanges || !Array.isArray(dateRanges)) return null;
  const targetDate = new Date(dateStr);
  for (const range of dateRanges) {
    const fromDate = new Date(range.fromDate);
    const toDate = new Date(range.toDate);
    if (targetDate >= fromDate && targetDate <= toDate) {
      return range;
    }
  }
  return null;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { items }: { items: CartItemRequest[] } = body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: 'Cart items are required' },
        { status: 400 }
      );
    }

    // Check if user has active agent subscription
    let hasActiveAgentSubscription = false;
    try {
      const supabase = createServerSupabaseClient();
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (session && session.user) {
        const userId = session.user.id;
        const { data: agent } = await supabaseAdmin
          .from('agents')
          .select('id, subscription_id, is_active')
          .eq('user_id', userId)
          .eq('is_active', true)
          .maybeSingle();

        if (agent && agent.subscription_id) {
          const { data: subscription } = await supabaseAdmin
            .from('subscriptions')
            .select('id, payment_status, is_active, end_date')
            .eq('id', agent.subscription_id)
            .single();

          if (
            subscription &&
            subscription.payment_status === 'completed' &&
            subscription.is_active === true &&
            new Date(subscription.end_date) > new Date()
          ) {
            hasActiveAgentSubscription = true;
          }
        }
      }
    } catch (error) {
      console.error('Error checking agent subscription:', error);
      // Continue without agent discount if check fails
    }

    // Fetch all packages at once (including date_ranges for flexible date pricing)
    const packageIds = items.map(item => item.packageId);
    const { data: packages, error: fetchError } = await supabaseAdmin
      .from('packages')
      .select(
        'package_id, package_name, package_price, adult_price, child_price, infant_price, solo_traveller_enabled, solo_traveller_price, with_visa, adult_visa_price, child_visa_price, infant_visa_price, package_nights, package_days, thumbnail_image, date_ranges, adult_discount_amount, child_discount_amount, infant_discount_amount, discount_start_date, discount_end_date, agent_discount'
      )
      .in('package_id', packageIds);

    if (fetchError) {
      return NextResponse.json({ error: fetchError.message }, { status: 400 });
    }

    // Validate and calculate prices for each cart item
    const validatedItems = await Promise.all(items.map(async item => {
      const pkg = packages?.find(p => p.package_id === item.packageId);

      if (!pkg) {
        return {
          packageId: item.packageId,
          valid: false,
          error: 'Package not found',
        };
      }

      // Validate adults, children, and infants are non-negative
      if (item.adults < 0 || item.children < 0 || item.infants < 0) {
        return {
          packageId: item.packageId,
          valid: false,
          error: 'Invalid person count',
        };
      }

      // Check if discount is active (only for non-flexible date packages)
      const discountActive = isDiscountActive(pkg);

      // Get date-specific pricing from date_ranges if a date is selected (for flexible date packages)
      // For tours/offer packages, even if selectedDate exists (from travel_dates), use columns
      let adultPrice = 0;
      let childPrice = 0;
      let infantPrice = 0;
      let soloTravellerPrice: number | null = null;
      let usePackagePriceAsFlatRate = false; // Flag to use package_price directly
      let isFlexibleDatePackage = false; // Flag to identify flexible date packages
      
      if (item.selectedDate) {
        // Check if this is a flexible date package by looking for the date in date_ranges
        const dateStr = item.selectedDate.split('T')[0];
        const dateRange = findDateRangeForDate(pkg.date_ranges, dateStr);
        
        if (dateRange) {
          // This is a flexible date package - use pricing from the date range
          isFlexibleDatePackage = true;
          adultPrice = dateRange.adultPrice || 0;
          childPrice = dateRange.childPrice || 0;
          infantPrice = dateRange.infantPrice || 0;
          soloTravellerPrice = dateRange.soloTravellerPrice ?? null;
        } else {
          // No date range found - this is a tour/offer package with selectedDate from travel_dates
          // Use package base prices from columns (for tours and offer packages)
          isFlexibleDatePackage = false;
          const hasPerPersonPricing = pkg.adult_price != null || pkg.child_price != null || pkg.infant_price != null;
          
          if (hasPerPersonPricing) {
            // Use per-person pricing from columns
            adultPrice = pkg.adult_price ?? 0;
            childPrice = pkg.child_price ?? 0;
            infantPrice = pkg.infant_price ?? 0;
          } else {
            // No per-person pricing set, will use package_price as flat rate
            usePackagePriceAsFlatRate = true;
          }
          soloTravellerPrice = pkg.solo_traveller_price ?? null;
        }
      } else {
        // If no date selected, use package base prices (for tours and offer packages)
        // Check if per-person prices are set (not null)
        const hasPerPersonPricing = pkg.adult_price != null || pkg.child_price != null || pkg.infant_price != null;
        
        if (hasPerPersonPricing) {
          // Use per-person pricing from columns
          adultPrice = pkg.adult_price ?? 0;
          childPrice = pkg.child_price ?? 0;
          infantPrice = pkg.infant_price ?? 0;
        } else {
          // No per-person pricing set, will use package_price as flat rate
          usePackagePriceAsFlatRate = true;
        }
        soloTravellerPrice = pkg.solo_traveller_price ?? null;
      }

      // Calculate price with discount applied
      let calculatedPrice = 0;
      let originalPrice = 0;
      const isSolo =
        item.isSoloTraveller && pkg.solo_traveller_enabled;

      if (isSolo) {
        // Solo traveller pricing overrides per-person logic (no discount on solo)
        // Use solo traveller price from date range if available, otherwise from package
        // For tours/offer packages, if solo_traveller_price is not set, fall back to package_price
        calculatedPrice = soloTravellerPrice ?? pkg.solo_traveller_price ?? (isFlexibleDatePackage ? 0 : (pkg.package_price ?? 0));
        originalPrice = calculatedPrice;
      } else {
        if (usePackagePriceAsFlatRate) {
          // No per-person pricing set, use package_price as flat rate (for tours and offer packages)
          calculatedPrice = pkg.package_price ?? 0;
          originalPrice = calculatedPrice;
        } else {
          // Regular pricing based on adult/child/infant counts from columns
          // Calculate original price first
          if (adultPrice > 0 && item.adults > 0) {
            originalPrice += adultPrice * item.adults;
          }
          if (childPrice > 0 && item.children > 0) {
            originalPrice += childPrice * item.children;
          }
          if (infantPrice > 0 && item.infants > 0) {
            originalPrice += infantPrice * item.infants;
          }

          // Calculate discounted price (only for non-flexible date packages)
          if (discountActive && !isFlexibleDatePackage) {
            const discountedAdultPrice = Math.max(0, adultPrice - (pkg.adult_discount_amount || 0));
            const discountedChildPrice = Math.max(0, childPrice - (pkg.child_discount_amount || 0));
            const discountedInfantPrice = Math.max(0, infantPrice - (pkg.infant_discount_amount || 0));

            if (item.adults > 0) {
              calculatedPrice += discountedAdultPrice * item.adults;
            }
            if (item.children > 0) {
              calculatedPrice += discountedChildPrice * item.children;
            }
            if (item.infants > 0) {
              calculatedPrice += discountedInfantPrice * item.infants;
            }
          } else {
            calculatedPrice = originalPrice;
          }

          // Fallback: If calculated price is still 0 and we have package_price, use it
          // This handles cases where:
          // 1. adult_price/child_price/infant_price are explicitly set to 0
          // 2. No adults/children/infants selected
          // 3. All prices are 0 but package_price exists
          // Only apply fallback for non-flexible date packages
          if (calculatedPrice === 0 && originalPrice === 0 && !isFlexibleDatePackage) {
            if (pkg.package_price && pkg.package_price > 0) {
              calculatedPrice = pkg.package_price;
              originalPrice = pkg.package_price;
            }
          }
        }
      }

      // Add visa pricing if enabled
      let visaPrice = 0;
      if (item.withVisa && pkg.with_visa) {
        if (pkg.adult_visa_price && item.visaForAdults && item.visaForAdults > 0) {
          visaPrice += pkg.adult_visa_price * item.visaForAdults;
        }
        if (pkg.child_visa_price && item.visaForChildren && item.visaForChildren > 0) {
          visaPrice += pkg.child_visa_price * item.visaForChildren;
        }
        if (pkg.infant_visa_price && item.visaForInfants && item.visaForInfants > 0) {
          visaPrice += pkg.infant_visa_price * item.visaForInfants;
        }
      }
      calculatedPrice += visaPrice;
      originalPrice += visaPrice;

      // Apply agent discount if user is an agent with active subscription (percentage-based)
      let agentDiscountAmount = 0;
      if (hasActiveAgentSubscription && pkg?.agent_discount && pkg.agent_discount > 0) {
        // agent_discount is now a percentage (e.g., 10 for 10%)
        const discountPercentage = pkg.agent_discount;
        agentDiscountAmount = (calculatedPrice * discountPercentage) / 100;
        calculatedPrice = Math.max(0, calculatedPrice - agentDiscountAmount);
      }

      return {
        packageId: item.packageId,
        valid: true,
        packageName: pkg.package_name,
        price: calculatedPrice,
        originalPrice: discountActive && originalPrice !== calculatedPrice ? originalPrice : null,
        adultPrice: discountActive && !isFlexibleDatePackage ? Math.max(0, adultPrice - (pkg.adult_discount_amount || 0)) : adultPrice,
        childPrice: discountActive && !isFlexibleDatePackage ? Math.max(0, childPrice - (pkg.child_discount_amount || 0)) : childPrice,
        infantPrice: discountActive && !isFlexibleDatePackage ? Math.max(0, infantPrice - (pkg.infant_discount_amount || 0)) : infantPrice,
        basePrice: pkg.package_price,
        nights: pkg.package_nights,
        days: pkg.package_days,
        thumbnailImage: pkg.thumbnail_image,
        // Discount info
        isDiscountActive: discountActive,
        adultDiscountAmount: discountActive ? pkg.adult_discount_amount : null,
        childDiscountAmount: discountActive ? pkg.child_discount_amount : null,
        infantDiscountAmount: discountActive ? pkg.infant_discount_amount : null,
        // Agent discount info
        agentDiscountAmount: hasActiveAgentSubscription && agentDiscountAmount > 0 ? agentDiscountAmount : null,
        // Visa info
        visaPrice: visaPrice,
        adultVisaPrice: pkg.adult_visa_price,
        childVisaPrice: pkg.child_visa_price,
        infantVisaPrice: pkg.infant_visa_price,
      };
    }));

    // Check if any items are invalid
    const invalidItems = validatedItems.filter(item => !item.valid);
    if (invalidItems.length > 0) {
      return NextResponse.json(
        {
          error: 'Some cart items are invalid',
          invalidItems,
        },
        { status: 400 }
      );
    }

    // At this point, all items are valid, so we can safely access price
    // Calculate total
    const total = validatedItems.reduce(
      (sum, item) => sum + (item.valid ? (item.price ?? 0) : 0),
      0
    );

    return NextResponse.json({
      success: true,
      items: validatedItems,
      total,
    });
  } catch (e: any) {
    return NextResponse.json(
      { error: e?.message ?? 'Unexpected error' },
      { status: 500 }
    );
  }
}
