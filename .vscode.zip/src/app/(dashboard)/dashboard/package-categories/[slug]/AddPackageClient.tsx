'use client';

import { useState, useTransition, useRef } from 'react';
import { useRouter } from 'next/navigation';
import TipTapEditor from '@/components/ui/TipTapEditor';
import { toast } from 'sonner';
import { uploadImageToCloudinary } from '@/lib/cloudinary';

export default function AddPackageClient({
  categoryId,
}: {
  categoryId: string;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState<string>('');
  const [status, setStatus] = useState('active');
  const [days, setDays] = useState<string>('');
  const [nights, setNights] = useState<string>('');
  const [travelDate, setTravelDate] = useState<string>('');
  const [travelDates, setTravelDates] = useState<
    Array<{ id: string; value: string }>
  >([]);
  const [adultPrice, setAdultPrice] = useState<string>('');
  const [childPrice, setChildPrice] = useState<string>('');
  const [infantPrice, setInfantPrice] = useState<string>('');
  const [termsHtml, setTermsHtml] = useState<string>('');
  const [inclusionHtml, setInclusionHtml] = useState<string>('');
  const [exclusionHtml, setExclusionHtml] = useState<string>('');
  const [overview, setOverview] = useState<string>('');
  const [holidayDescHtml, setHolidayDescHtml] = useState<string>('');
  const [itinerary, setItinerary] = useState<
    Array<{ id: string; heading: string; desc: string }>
  >([
    {
      id: (crypto.randomUUID?.() || String(Date.now())) + '-0',
      heading: '',
      desc: '',
    },
  ]);
  const [thumbnailImage, setThumbnailImage] = useState<File | null>(null);
  const [thumbnailImagePreview, setThumbnailImagePreview] =
    useState<string>('');
  const [thumbnailImageUrl, setThumbnailImageUrl] = useState<string>('');
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [imageLoadError, setImageLoadError] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  return (
    <>
      <button className='btn_primary' onClick={() => setOpen(true)}>
        Add Package
      </button>
      {open && (
        <div className='modal_overlay' onClick={() => setOpen(false)}>
          <div
            className='modal category_modal'
            onClick={e => e.stopPropagation()}
          >
            <div className='modal_header'>
              <h4>Add Package</h4>
              <button className='modal_close' onClick={() => setOpen(false)}>
                ×
              </button>
            </div>
            <div className='modal_body'>
              {/* Basic Information Section */}
              <div className='form_section'>
                <h5 className='section_title'>Basic Information</h5>
                <div className='form_grid'>
                  <div className='form_row full_width'>
                    <label>Package Name *</label>
                    <input
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder='Enter package name'
                    />
                  </div>

                  <div className='form_row full_width'>
                    <label>Thumbnail Image</label>
                    <input
                      ref={fileInputRef}
                      type='file'
                      accept='image/*'
                      onChange={async e => {
                        const file = e.target.files?.[0];
                        if (!file) return;

                        // Validate file type
                        if (!file.type.startsWith('image/')) {
                          toast.error('Please select a valid image file');
                          return;
                        }

                        // Validate file size (max 5MB)
                        if (file.size > 5 * 1024 * 1024) {
                          toast.error('Image size should be less than 5MB');
                          return;
                        }

                        setThumbnailImage(file);
                        setImageLoadError(false);
                        // Create preview
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          setThumbnailImagePreview(reader.result as string);
                        };
                        reader.readAsDataURL(file);

                        // Upload to Cloudinary
                        setIsUploadingImage(true);
                        try {
                          const url = await uploadImageToCloudinary(
                            file,
                            'packages'
                          );
                          setThumbnailImageUrl(url);
                          toast.success('Image uploaded successfully');
                        } catch (error) {
                          console.error('Upload error:', error);
                          toast.error(
                            error instanceof Error
                              ? error.message
                              : 'Failed to upload image'
                          );
                          setThumbnailImage(null);
                          setThumbnailImagePreview('');
                          if (fileInputRef.current) {
                            fileInputRef.current.value = '';
                          }
                        } finally {
                          setIsUploadingImage(false);
                        }
                      }}
                      disabled={isUploadingImage}
                    />
                    {thumbnailImagePreview &&
                      thumbnailImagePreview.trim() &&
                      !imageLoadError && (
                        <div className='image_preview_container'>
                          <img
                            src={thumbnailImagePreview}
                            alt='Thumbnail preview'
                            onError={() => {
                              setImageLoadError(true);
                            }}
                            onLoad={() => {
                              setImageLoadError(false);
                            }}
                            className='image_preview'
                          />
                          <button
                            type='button'
                            className='btn_remove_image'
                            onClick={() => {
                              setThumbnailImage(null);
                              setThumbnailImagePreview('');
                              setThumbnailImageUrl('');
                              setImageLoadError(false);
                              if (fileInputRef.current) {
                                fileInputRef.current.value = '';
                              }
                            }}
                          >
                            Remove Image
                          </button>
                        </div>
                      )}
                    {isUploadingImage && (
                      <p className='upload_status'>Uploading image...</p>
                    )}
                  </div>

                  <div className='form_row full_width'>
                    <label>Description</label>
                    <textarea
                      value={description}
                      onChange={e => setDescription(e.target.value)}
                      placeholder='Enter short description'
                      rows={3}
                    />
                  </div>

                  <div className='form_row'>
                    <label>Days</label>
                    <select
                      value={days}
                      onChange={e => setDays(e.target.value)}
                    >
                      <option value=''>Select days</option>
                      {Array.from({ length: 10 }).map((_, i) => (
                        <option key={i + 1} value={i + 1}>
                          {i + 1} {i + 1 === 1 ? 'Day' : 'Days'}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className='form_row'>
                    <label>Nights</label>
                    <select
                      value={nights}
                      onChange={e => setNights(e.target.value)}
                    >
                      <option value=''>Select nights</option>
                      {Array.from({ length: 10 }).map((_, i) => (
                        <option key={i + 1} value={i + 1}>
                          {i + 1} {i + 1 === 1 ? 'Night' : 'Nights'}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className='form_row full_width'>
                    <label>Travel Dates</label>
                    <div className='date_input_group'>
                      <input
                        type='date'
                        value={travelDate}
                        onChange={e => setTravelDate(e.target.value)}
                      />
                      <button
                        type='button'
                        className='btn_add_date'
                        onClick={() => {
                          if (!travelDate) {
                            toast.error('Please select a date to add');
                            return;
                          }
                          if (travelDates.some(t => t.value === travelDate)) {
                            toast.error('Date already added');
                            return;
                          }
                          setTravelDates(prev => [
                            ...prev,
                            {
                              id: crypto.randomUUID?.() || String(Date.now()),
                              value: travelDate,
                            },
                          ]);
                          setTravelDate('');
                        }}
                      >
                        + Add Date
                      </button>
                    </div>
                    {travelDates.length > 0 && (
                      <div className='date_chips'>
                        {travelDates.map(d => (
                          <span key={d.id} className='date_chip'>
                            {new Date(d.value).toLocaleDateString()}
                            <button
                              type='button'
                              onClick={() =>
                                setTravelDates(prev =>
                                  prev.filter(x => x.id !== d.id)
                                )
                              }
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className='form_row'>
                    <label>Status</label>
                    <select
                      value={status}
                      onChange={e => setStatus(e.target.value)}
                    >
                      <option value='active'>Active</option>
                      <option value='inactive'>Inactive</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Pricing Section */}
              <div className='form_section'>
                <h5 className='section_title'>Pricing</h5>
                <div className='form_grid pricing_grid'>
                  <div className='form_row'>
                    <label>Base Price *</label>
                    <input
                      type='number'
                      value={price}
                      onChange={e => setPrice(e.target.value)}
                      placeholder='999'
                    />
                  </div>

                  <div className='form_row'>
                    <label>Adult Price</label>
                    <input
                      type='number'
                      value={adultPrice}
                      onChange={e => setAdultPrice(e.target.value)}
                      placeholder='1299'
                    />
                  </div>

                  <div className='form_row'>
                    <label>Child Price</label>
                    <input
                      type='number'
                      value={childPrice}
                      onChange={e => setChildPrice(e.target.value)}
                      placeholder='899'
                    />
                  </div>

                  <div className='form_row'>
                    <label>Infant Price</label>
                    <input
                      type='number'
                      value={infantPrice}
                      onChange={e => setInfantPrice(e.target.value)}
                      placeholder='499'
                    />
                  </div>
                </div>
              </div>

              {/* Package Details Section */}
              <div className='form_section'>
                <h5 className='section_title'>Package Details</h5>

                <div className='form_row full_width'>
                  <label>Overview</label>
                  <textarea
                    value={overview}
                    onChange={e => setOverview(e.target.value)}
                    placeholder='Enter package overview'
                    rows={4}
                  />
                </div>

                <div className='form_row full_width'>
                  <label>Holiday Description</label>
                  <TipTapEditor
                    content={holidayDescHtml}
                    onChange={setHolidayDescHtml}
                    height={180}
                  />
                </div>

                <div className='form_row full_width'>
                  <label>Terms & Conditions</label>
                  <TipTapEditor
                    content={termsHtml}
                    onChange={setTermsHtml}
                    height={140}
                  />
                </div>

                <div className='form_row full_width'>
                  <label>Inclusions</label>
                  <TipTapEditor
                    content={inclusionHtml}
                    onChange={setInclusionHtml}
                    height={140}
                  />
                </div>

                <div className='form_row full_width'>
                  <label>Exclusions</label>
                  <TipTapEditor
                    content={exclusionHtml}
                    onChange={setExclusionHtml}
                    height={140}
                  />
                </div>
              </div>

              {/* Itinerary Section */}
              <div className='form_section'>
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}
                >
                  <h5 className='section_title'>Itinerary</h5>
                  <button
                    type='button'
                    className='btn_add_itinerary'
                    onClick={() =>
                      setItinerary(prev => [
                        ...prev,
                        {
                          id:
                            crypto.randomUUID?.() ||
                            String(Date.now() + prev.length),
                          heading: '',
                          desc: '',
                        },
                      ])
                    }
                  >
                    + Add Day
                  </button>
                </div>

                <div className='itinerary_list'>
                  {itinerary.map((item, idx) => (
                    <div key={item.id} className='itinerary_item'>
                      <div className='itinerary_header'>
                        <span className='itinerary_day'>Day {idx + 1}</span>
                        {itinerary.length > 1 && (
                          <button
                            type='button'
                            className='btn_remove_itinerary'
                            onClick={() =>
                              setItinerary(prev =>
                                prev.filter(x => x.id !== item.id)
                              )
                            }
                          >
                            Remove
                          </button>
                        )}
                      </div>
                      <div className='form_row'>
                        <label>Heading</label>
                        <TipTapEditor
                          content={item.heading}
                          onChange={v => {
                            setItinerary(prev =>
                              prev.map(x =>
                                x.id === item.id ? { ...x, heading: v } : x
                              )
                            );
                          }}
                          height={100}
                        />
                      </div>
                      <div className='form_row'>
                        <label>Description</label>
                        <TipTapEditor
                          content={item.desc}
                          onChange={v => {
                            setItinerary(prev =>
                              prev.map(x =>
                                x.id === item.id ? { ...x, desc: v } : x
                              )
                            );
                          }}
                          height={140}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className='modal_footer'>
              <button onClick={() => setOpen(false)} disabled={isPending}>
                Cancel
              </button>
              <button
                className='btn_primary'
                disabled={
                  !name.trim() ||
                  !price ||
                  Number.isNaN(Number(price)) ||
                  isPending
                }
                onClick={() =>
                  startTransition(async () => {
                    try {
                      if (!name.trim()) {
                        toast.error('Name is required');
                        return;
                      }
                      if (!price || Number.isNaN(Number(price))) {
                        toast.error('Valid price is required');
                        return;
                      }
                      const res = await fetch('/api/packages', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          name: name.trim(),
                          description: description.trim() || undefined,
                          price: Number(price),
                          status,
                          category_id: categoryId,
                          days: days ? Number(days) : undefined,
                          nights: nights ? Number(nights) : undefined,
                          travel_dates: travelDates,
                          adult_price: adultPrice
                            ? Number(adultPrice)
                            : undefined,
                          child_price: childPrice
                            ? Number(childPrice)
                            : undefined,
                          infant_price: infantPrice
                            ? Number(infantPrice)
                            : undefined,
                          terms_html: termsHtml || undefined,
                          inclusion_html: inclusionHtml || undefined,
                          exclusion_html: exclusionHtml || undefined,
                          overview: overview || undefined,
                          holiday_description_html:
                            holidayDescHtml || undefined,
                          itinerary: itinerary,
                          thumbnail_image: thumbnailImageUrl || undefined,
                        }),
                      });
                      if (!res.ok) {
                        const j = await res.json().catch(() => ({}));
                        throw new Error(j?.error ?? 'Failed to add package');
                      }
                      setOpen(false);
                      // Reset form
                      setName('');
                      setDescription('');
                      setPrice('');
                      setDays('');
                      setNights('');
                      setTravelDates([]);
                      setAdultPrice('');
                      setChildPrice('');
                      setInfantPrice('');
                      setTermsHtml('');
                      setInclusionHtml('');
                      setExclusionHtml('');
                      setOverview('');
                      setHolidayDescHtml('');
                      setItinerary([
                        {
                          id:
                            (crypto.randomUUID?.() || String(Date.now())) +
                            '-0',
                          heading: '',
                          desc: '',
                        },
                      ]);
                      setThumbnailImage(null);
                      setThumbnailImagePreview('');
                      setThumbnailImageUrl('');
                      setImageLoadError(false);
                      if (fileInputRef.current) {
                        fileInputRef.current.value = '';
                      }
                      // Refresh current route to show the new package
                      router.refresh();
                      // Also notify list to refetch
                      try {
                        window.dispatchEvent(
                          new CustomEvent('packages:changed')
                        );
                      } catch {}
                      toast.success('Package added');
                    } catch (e) {
                      console.error(e);
                      toast.error(
                        e instanceof Error ? e.message : 'Failed to add package'
                      );
                    }
                  })
                }
              >
                {isPending ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
