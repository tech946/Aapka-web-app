import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface CreateCCAvenueOrderRequest {
  amount: number; // Amount in INR
  currency: string;
  bookingId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  paymentType: 'half' | 'full';
}

export async function POST(req: NextRequest) {
  try {
    const body: CreateCCAvenueOrderRequest = await req.json();
    const { amount, currency, bookingId, customerName, customerEmail, customerPhone, paymentType } = body;

    if (!amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Invalid amount' },
        { status: 400 }
      );
    }

    if (!bookingId) {
      return NextResponse.json(
        { error: 'Booking ID is required' },
        { status: 400 }
      );
    }

    const merchantId = process.env.CCAVENUE_MERCHANT_ID || '';
    const accessCode = process.env.CCAVENUE_ACCESS_CODE || '';
    const workingKey = process.env.CCAVENUE_WORKING_KEY || '';

    if (!merchantId || !accessCode || !workingKey) {
      return NextResponse.json(
        { error: 'CCAvenue credentials not configured' },
        { status: 500 }
      );
    }

    // Create order ID
    const orderId = `booking_${bookingId}_${Date.now()}`;

    // Prepare payment parameters
    const paymentParams = {
      merchant_id: merchantId,
      order_id: orderId,
      amount: amount.toFixed(2),
      currency: currency || 'INR',
      redirect_url: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/payments/ccavenue/callback`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/checkout?error=payment_cancelled`,
      billing_name: customerName,
      billing_email: customerEmail,
      billing_tel: customerPhone,
      billing_address: '',
      billing_city: '',
      billing_state: '',
      billing_zip: '',
      billing_country: '',
      delivery_name: customerName,
      delivery_address: '',
      delivery_city: '',
      delivery_state: '',
      delivery_zip: '',
      delivery_country: '',
      merchant_param1: bookingId,
      merchant_param2: paymentType,
    };

    // Create encrypted data
    const plainText = Object.entries(paymentParams)
      .map(([key, value]) => `${key}=${value}`)
      .join('&');

    const encryptedData = encrypt(plainText, workingKey);

    return NextResponse.json({
      success: true,
      merchantId,
      accessCode,
      encryptedData,
      orderId,
      redirectUrl: process.env.CCAVENUE_PAYMENT_URL || 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction',
    });
  } catch (error: any) {
    console.error('Error creating CCAvenue order:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to create payment order' },
      { status: 500 }
    );
  }
}

// CCAvenue encryption function
// Note: CCAvenue uses AES encryption. For production, use CCAvenue's official encryption library
// or implement AES-128-CBC encryption as per their documentation
function encrypt(plainText: string, key: string): string {
  try {
    const algorithm = 'aes-128-cbc';
    
    // CCAvenue expects the key to be used for AES encryption
    // The working key should be 16 bytes for AES-128
    const keyBuffer = Buffer.from(key.substring(0, 16), 'utf8');
    const iv = Buffer.alloc(16, 0); // IV should be all zeros for CCAvenue
    
    const cipher = crypto.createCipheriv(algorithm, keyBuffer, iv);
    let encrypted = cipher.update(plainText, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    
    return encrypted;
  } catch (error) {
    console.error('Encryption error:', error);
    // Fallback to simple base64 encoding (not secure, for testing only)
    return Buffer.from(plainText).toString('base64');
  }
}

