'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { ChevronDown, ShoppingCart } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import './header.css';

interface Category {
  id: string;
  name: string;
}

export default function Header() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [isPackagesDropdownOpen, setIsPackagesDropdownOpen] = useState(false);
  const { getTotalItems } = useCart();
  const cartItemCount = getTotalItems();

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch('/api/package-categories?limit=100');
        const result = await response.json();
        if (result.data) {
          setCategories(result.data);
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    };
    fetchCategories();
  }, []);

  const getCategorySlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '');
  };

  return (
    <header className='header'>
      <div className='header__container'>
        <Link href='/' className='header__logo'>
          <img src='/aapka-tourism-logo.png' alt='Logo' />
        </Link>
        <div className='navbar'>
          <ul>
            <li>
              <Link href='/' className='header-nav-link'>
                Home
              </Link>
            </li>
            <li className='header-dropdown-container'>
              <button
                className='header-dropdown-button'
                onClick={() =>
                  setIsPackagesDropdownOpen(!isPackagesDropdownOpen)
                }
              >
                Packages
                <ChevronDown
                  size={16}
                  className={`header-chevron ${
                    isPackagesDropdownOpen ? 'open' : ''
                  }`}
                />
              </button>
              {isPackagesDropdownOpen && (
                <>
                  <div
                    className='header-dropdown-overlay'
                    onClick={() => setIsPackagesDropdownOpen(false)}
                  />
                  <div className='header-dropdown-menu'>
                    {categories.length > 0 ? (
                      categories.map(category => (
                        <Link
                          key={category.id}
                          href={`/category/${getCategorySlug(category.name)}`}
                          className='header-dropdown-item'
                          onClick={() => setIsPackagesDropdownOpen(false)}
                        >
                          {category.name}
                        </Link>
                      ))
                    ) : (
                      <div className='header-dropdown-item disabled'>
                        No categories available
                      </div>
                    )}
                  </div>
                </>
              )}
            </li>
            <li>
              <Link href='/About' className='header-nav-link'>
                About
              </Link>
            </li>
            <li>
              <Link href='/contact' className='header-nav-link'>
                Contact Us
              </Link>
            </li>
            <li>
              <Link href='/cart' className='header-cart-link'>
                <ShoppingCart size={20} />
                {cartItemCount > 0 && (
                  <span className='header-cart-badge'>{cartItemCount}</span>
                )}
              </Link>
            </li>
            <li>
              <a href='tel:+971501234567' className='header-call-button'>
                Call Us
              </a>
            </li>
          </ul>
        </div>
      </div>
    </header>
  );
}
